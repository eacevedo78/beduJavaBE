package org.bedu.apipokemon;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiPokemonApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiPokemonApplication.class, args);
	}

}
