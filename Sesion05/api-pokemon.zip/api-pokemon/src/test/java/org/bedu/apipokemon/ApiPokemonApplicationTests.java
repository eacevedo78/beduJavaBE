package org.bedu.apipokemon;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiPokemonApplicationTests {

	@Test
	void contextLoads() {
	}

}
