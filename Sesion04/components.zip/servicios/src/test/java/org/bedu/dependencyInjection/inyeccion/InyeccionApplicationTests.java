package org.bedu.dependencyInjection.inyeccion;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InyeccionApplicationTests {

	@Test
	void contextLoads() {
	}

}
