package org.bedu.dependencyInjection.inyeccion;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InyeccionApplication {

	public static void main(String[] args) {
		SpringApplication.run(InyeccionApplication.class, args);
	}

}
